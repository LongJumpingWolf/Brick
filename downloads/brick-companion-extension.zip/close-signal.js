'use strict';
/* =====================================================================
   close-signal.js — the ONLY content script that runs persistently
   (world: isolated, the default — it never touches __brickBridge
   directly, just tells the background "this tab might be going
   away"). Everything else stays exactly as it was: the background
   still uses on-demand chrome.scripting.executeScript() to actually
   read __brickBridge and run a sync, via the exact same
   BrickBackupCore.runSync() already covered by 40 tests. This file's
   entire job is triggering that at the earliest realistic moment.

   Why visibilitychange AND pagehide, both: visibilitychange (hidden)
   fires when a tab is backgrounded OR starts closing — including for
   a BACKGROUND tab when the whole browser quits, not just the active
   one, since Chrome runs the normal unload lifecycle for every open
   tab during shutdown, not only the focused tab. pagehide fires
   closer to actual teardown. Listening for both maximizes the chance
   of catching the moment while the page (and therefore __brickBridge)
   is still alive enough for the background's executeScript-based
   sync to actually complete — but it is NOT a guarantee. There is no
   way to know for certain how much time remains before the process
   is gone; this is genuinely best-effort, not a hard promise, and
   said that plainly rather than implied otherwise.

   Fires on EVERY tab-hide, not just closing — switching away to
   another tab triggers this too, not only quitting. That's
   intentional and cheap: background-core.js's own dirty-check means
   a trigger with nothing actually changed does effectively no work
   (one execInPage round-trip, no real sync activity), so firing
   liberally costs little and only pays off on the moments that
   actually matter. */

function signalPossibleClose(){
  try {
    chrome.runtime.sendMessage({ type: 'brick-tab-hidden-or-closing' });
  } catch (err){
    // the extension context can itself be mid-reload/invalidated at
    // exactly this moment (e.g. right as the browser is quitting) —
    // nothing meaningful to do about that, just don't let it throw
  }
}

document.addEventListener('visibilitychange', () => {
  if (document.hidden) signalPossibleClose();
});
window.addEventListener('pagehide', signalPossibleClose);
