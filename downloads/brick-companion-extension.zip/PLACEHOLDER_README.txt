This is a placeholder.

The Brick companion browser extension isn't built yet — this file
exists so the "Download Companion Extension" button in Settings has
something real to download right now instead of a broken link or a
404, rather than leaving it silently non-functional until the real
extension is ready.

Once the actual extension is finished, this placeholder gets replaced
with the real .zip at this same path — the button itself doesn't need
any code changes when that happens.
