# Brick Companion Backup

Personal-use browser extension. Mirrors your Brick Wall/Brick tree to a
`BrickBackups/` folder inside your normal Downloads folder — one real
subfolder per Wall, one real `.json` file per Brick, kept in sync
automatically. Not published to the Chrome Web Store; loaded unpacked
via Developer Mode.

## Install

1. `chrome://extensions`
2. Toggle **Developer mode** on (top right)
3. **Load unpacked** → select this folder
4. Pin it to the toolbar if you want the popup easily reachable

## Before it'll actually work on your deployment

Open `manifest.json` and check `host_permissions`. It already covers:

- `https://*.vercel.app/*` — if Brick is deployed at some `*.vercel.app`
  subdomain, this already works, nothing to change.
- `http://localhost/*` and `http://127.0.0.1/*` — for local testing.

**If Brick is on a custom domain instead**, add it to that array, e.g.
`"https://your-actual-domain.com/*"`, then reload the extension from
`chrome://extensions` (the reload icon on the extension's card) for
the change to take effect.

## How it actually works

- `background-core.js` — the real decision logic (which tab, is the
  bridge ready, dirty-check, retry/failure handling). Deliberately
  written against a plain `api` object instead of calling `chrome.*`
  directly, so it's testable under plain Node — see `test/`, 26
  assertions covering the worst cases (no tab open, the bridge
  missing/not-ready, a file failing mid-batch without aborting the
  rest, overlapping syncs being refused rather than racing).
- `background.js` — wires that logic to the real browser: finds the
  Brick tab, injects a tiny function into its page via
  `chrome.scripting.executeScript(..., { world: 'MAIN' })` to read
  `window.__brickBridge` directly (content scripts run in an isolated
  JS world and can't see page globals — `world: 'MAIN'` sidesteps that
  without needing a persistent injected script or a postMessage relay),
  then writes each file via `chrome.downloads.download()` with a
  `data:` URL (avoids service-worker `URL.createObjectURL`
  limitations entirely) and `conflictAction: 'overwrite'`.
- Syncs on a `chrome.alarms` timer (survives service worker restarts,
  unlike a plain `setInterval` would in Manifest V3) every 5 minutes,
  and on-demand via the popup's "Sync now" button.
- `window.__brickBridge` (on the Brick side, `js/extension-bridge.js`)
  is the whole contract — versioned (`BRIDGE_VERSION`), so an
  incompatible future change on either side is something that gets
  *detected* (logged, sync still attempted) rather than silently
  producing wrong data.

## Run the tests

```bash
node test/background-core.test.js
```

No browser, no jsdom — `background-core.js` is plain Node-compatible
by design.

## What this can't do

Same as the in-page Linked Backup Folder version: nothing here
protects against the browser's storage being wiped entirely if it
never gets a chance to sync first (e.g. mid-edit, before the next
alarm or a manual sync). Both mechanisms are best-effort automation,
not a substitute for occasionally checking that `BrickBackups/`
actually has recent files in it.
