# Brick Companion Backup

Personal-use browser extension. Mirrors your Brick Wall/Brick tree to a
`BrickBackups/` folder inside your normal Downloads folder — one real
subfolder per Wall, one real `.json` file per Brick, kept in sync
automatically. Not published to the Chrome Web Store; loaded unpacked
via Developer Mode.

## Install

1. `chrome://extensions`
2. Toggle **Developer mode** on (top right)
3. **Load unpacked** → select this folder
4. Pin it to the toolbar if you want the popup easily reachable

## Before it'll actually work on your deployment

Open `manifest.json` and check `host_permissions`. It already covers:

- `https://*.vercel.app/*` — if Brick is deployed at some `*.vercel.app`
  subdomain, this already works, nothing to change.
- `http://localhost/*` and `http://127.0.0.1/*` — for local testing.

**If Brick is on a custom domain instead**, add it to that array, e.g.
`"https://your-actual-domain.com/*"`, **and also add the exact same
entry to `content_scripts[0].matches`** — that second array controls
where `close-signal.js` (the close/tab-hide trigger) actually gets
injected, separately from `host_permissions`. Missing that second
edit doesn't break the alarm-timer or manual "Sync now" sync — only
the close-triggered one, silently. Then reload the extension from
`chrome://extensions` (the reload icon on the extension's card) for
the change to take effect.

## How it actually works

- `background-core.js` — the real decision logic (which tab, is the
  bridge ready, dirty-check, retry/failure handling, and **real sync
  with a Trash**: a Brick deleted in the app gets its mirrored file
  moved into a flat `Trash/` folder — original path folded into the
  filename plus a deletion timestamp, so deleting the same name twice
  can never overwrite an earlier trashed copy). Deliberately written
  against a plain `api` object instead of calling `chrome.*` directly,
  so it's testable under plain Node — see `test/`, 40 assertions,
  including true unchanged files correctly making zero write calls
  (confirmed at the actual download-call level, not just the reported
  label) verified inside a single mixed sync where one file is
  unchanged, one updated, and one brand new all at once, each getting
  its own independent, correct decision.
  There's no "move" in the downloads API, only download-new +
  `chrome.downloads.removeFile()` on the original — which is why the
  full *content* of every synced file, not just its path, gets
  persisted between runs in `chrome.storage.local`, not only a list of
  what exists.
- `background.js` — wires that logic to the real browser: finds the
  Brick tab, injects a tiny function into its page via
  `chrome.scripting.executeScript(..., { world: 'MAIN' })` to read
  `window.__brickBridge` directly (content scripts run in an isolated
  JS world and can't see page globals — `world: 'MAIN'` sidesteps that
  without needing a persistent injected script or a postMessage relay),
  then writes each file via `chrome.downloads.download()` with a
  `data:` URL (avoids service-worker `URL.createObjectURL`
  limitations entirely) and `conflictAction: 'overwrite'`.
- `close-signal.js` — the one content script that runs on every page
  load (everything else is on-demand injection, not persistent). Its
  entire job: tell the background "this tab might be closing" via
  `visibilitychange` (hidden) and `pagehide`, as early as realistically
  possible. This is what makes closing the whole browser — not just
  the Brick tab itself — trigger a sync, including when Brick is
  sitting in a **background** tab at the time, since Chrome runs the
  normal page-hide lifecycle for every open tab during shutdown, not
  only the focused one. Fires on ordinary tab-switching too, not just
  closing — intentional, since `background-core.js`'s own dirty-check
  already makes a trigger with nothing changed cheap (one quick check,
  no real sync work), so firing liberally costs little.
  **Genuinely best-effort, not a guarantee** — once a tab is actually
  torn down, `chrome.scripting.executeScript()` has nothing left to
  inject into, so there's a real race between "the signal fires" and
  "the page is gone." This maximizes the chance of catching a
  last-second change; it doesn't promise it.
  **Not unit-tested, and said so plainly rather than papered over:**
  unlike `background-core.js`, there's no real decision logic here to
  extract into something Node can verify — it's two DOM event
  listeners firing one fixed message, and the only genuinely uncertain
  part (does the background actually receive it before the page dies)
  is real browser page-lifecycle behavior no test harness here can
  simulate. Verify it by installing the extension for real: open
  Brick in a background tab, close the browser, reopen it, and check
  `BrickBackups/` for a recent timestamp.
- Syncs on a `chrome.alarms` timer (survives service worker restarts,
  unlike a plain `setInterval` would in Manifest V3) every 5 minutes,
  on-demand via the popup's "Sync now" button, and via `close-signal.js`
  above.
- `window.__brickBridge` (on the Brick side, `js/extension-bridge.js`)
  is the whole contract — versioned (`BRIDGE_VERSION`), so an
  incompatible future change on either side is something that gets
  *detected* (logged, sync still attempted) rather than silently
  producing wrong data.

## Run the tests

```bash
node test/background-core.test.js
```

No browser, no jsdom — `background-core.js` is plain Node-compatible
by design.

## A real storage constraint worth knowing about

The trash-diff mechanism needs the *full content* of every synced
file available between runs (there's no way to read a file's content
back off disk through `chrome.downloads` once it's written — only the
Brick page still has that, and by the time something's deleted, it no
longer does either). That gets persisted in `chrome.storage.local`,
which defaults to roughly 10MB total — genuinely tight for an
image-heavy library, since occlusion cards carry base64 image data.
`manifest.json` requests the `unlimitedStorage` permission specifically
for this reason. It's a real, deliberate ask, not boilerplate — happy
to revisit if it ever feels like more than a personal backup tool
should need.

## What this can't do

Same as the in-page Linked Backup Folder version: nothing here
protects against the browser's storage being wiped entirely if it
never gets a chance to sync first (e.g. mid-edit, before the next
alarm or a manual sync). Both mechanisms are best-effort automation,
not a substitute for occasionally checking that `BrickBackups/`
actually has recent files in it.
