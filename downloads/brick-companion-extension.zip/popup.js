document.getElementById('syncBtn').addEventListener('click', () => {
  const statusEl = document.getElementById('status');
  statusEl.textContent = 'Syncing…';
  chrome.runtime.sendMessage({ type: 'sync-now' }, (result) => {
    if (!result){ statusEl.textContent = 'No response from the background worker.'; return; }
    const lines = [
      'Result: ' + result.reason + (result.ok ? '' : ' (not fully successful)'),
      typeof result.created === 'number' ? 'Created: ' + result.created + ', updated: ' + result.updated + ', unchanged: ' + result.unchanged : '',
      typeof result.trashed === 'number' && result.trashed > 0 ? 'Moved to Trash: ' + result.trashed : '',
      typeof result.failed === 'number' && result.failed > 0 ? 'Failed to write: ' + result.failed : '',
      typeof result.trashFailed === 'number' && result.trashFailed > 0 ? 'Failed to trash: ' + result.trashFailed : '',
      ...(result.log || [])
    ].filter(Boolean);
    statusEl.textContent = lines.join('\n');
  });
});
