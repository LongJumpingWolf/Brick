document.getElementById('syncBtn').addEventListener('click', () => {
  const statusEl = document.getElementById('status');
  statusEl.textContent = 'Syncing…';
  chrome.runtime.sendMessage({ type: 'sync-now' }, (result) => {
    if (!result){ statusEl.textContent = 'No response from the background worker.'; return; }
    const lines = [
      'Result: ' + result.reason + (result.ok ? '' : ' (not fully successful)'),
      typeof result.written === 'number' ? 'Written: ' + result.written + ', failed: ' + result.failed : '',
      ...(result.log || [])
    ].filter(Boolean);
    statusEl.textContent = lines.join('\n');
  });
});
