(function(root, factory){
  if (typeof module !== 'undefined' && module.exports){
    module.exports = factory();
  } else {
    root.BrickBackupCore = factory();
  }
})(typeof self !== 'undefined' ? self : this, function(){
  'use strict';
  /* =====================================================================
     background-core.js — the actual decision logic for the companion
     extension's sync, deliberately free of any direct chrome.* calls.
     Everything the extension needs from the browser is passed in as
     `api` (queryTabs / execInPage / download / removeFile / storageGet
     / storageSet), so this exact file runs unmodified both inside the
     real extension (wired to real chrome.* calls in background.js)
     and under a plain Node test with a mock `api` — no browser, no
     jsdom, needed to verify the actual worst-case handling here.

     Real sync, not just accumulation: a file whose Brick was deleted
     in the app gets moved into a flat Trash/ subfolder (original path
     folded into the filename, plus a deletion timestamp so deleting →
     recreating → deleting the same name twice can never overwrite an
     earlier trashed copy) rather than either sitting there stale
     forever or being silently destroyed. Same behavior as the in-page
     File System Access version in backup-folder.js — one mirroring
     policy, not two that could drift apart. The one real difference:
     chrome.downloads can't just "move" a file, so this downloads the
     OLD cached content fresh to the Trash/ path, then calls
     removeFile() on the original's downloadId — which is exactly why
     the full {content, downloadId} of every file, not just its path,
     has to be persisted between syncs; there is no way to read a
     file's content back off disk through this API once it's already
     been written.
     ===================================================================== */

  const BRIDGE_VERSION_EXPECTED = 1;

  /* Multiple Brick tabs open at once — pick the most recently active
     one. Not perfect (there's no way to know which one the person
     actually considers "current"), but it's a reasonable, deterministic
     default rather than an arbitrary/undefined one. */
  function pickBrickTab(tabs){
    if (!tabs || !tabs.length) return null;
    return tabs.slice().sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  }

  function trashFileName(relativePath){
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const flat = relativePath.replace(/\//g, ' - ').replace(/\.json$/, '');
    return flat + ' (deleted ' + stamp + ').json';
  }

  /* Same reasoning as backup-folder.js's version of this: every
     Brick's exported bundle carries a fresh exportedAt: Date.now(),
     so a raw string/length comparison can never detect "genuinely
     unchanged" — two calls for the exact same content still differ
     purely because of when each ran. Normalizing that one field out
     first is what makes "did anything real change" actually mean
     that. */
  function contentsEquivalent(a, b){
    if (a === b) return true;
    try {
      const pa = JSON.parse(a), pb = JSON.parse(b);
      pa.exportedAt = 0; pb.exportedAt = 0;
      return JSON.stringify(pa) === JSON.stringify(pb);
    } catch (err){
      return false;
    }
  }

  let syncInFlight = false;

  async function runSync(api, opts){
    opts = opts || {};
    const log = [];
    const record = (msg) => { log.push(msg); return log; };
    const subfolder = opts.subfolder || 'BrickBackups';

    if (syncInFlight) return { ok:false, reason:'already-in-progress', log: record('a sync was already running — this call was skipped rather than allowed to overlap it') };
    syncInFlight = true;

    try {
      let tabs;
      try {
        tabs = await api.queryTabs({ url: opts.matchUrls || ['*://*/*'] });
      } catch (err){
        return { ok:false, reason:'tab-query-failed', log: record('tab query failed: ' + err) };
      }

      const tab = pickBrickTab(tabs);
      if (!tab) return { ok:false, reason:'no-tab', log: record('no matching Brick tab is currently open') };

      let bridgeCheck;
      try {
        bridgeCheck = await api.execInPage(tab.id, 'checkBridge');
      } catch (err){
        return { ok:false, reason:'exec-failed', log: record('could not run a check in the page — extension may lack permission for this tab: ' + err) };
      }
      if (!bridgeCheck || !bridgeCheck.present){
        return { ok:false, reason:'bridge-missing', log: record('the page has no __brickBridge — either not loaded yet, or an old Brick version without this feature') };
      }
      if (!bridgeCheck.ready){
        return { ok:false, reason:'not-ready', log: record('bridge is present but the app has not finished booting yet') };
      }
      if (bridgeCheck.version !== BRIDGE_VERSION_EXPECTED){
        record('bridge version mismatch — extension expects ' + BRIDGE_VERSION_EXPECTED + ', page reports ' + bridgeCheck.version + ' — attempting anyway rather than refusing outright');
      }

      let planResult;
      try {
        planResult = await api.execInPage(tab.id, 'getMirrorPlan');
      } catch (err){
        return { ok:false, reason:'plan-exec-failed', log: record('getMirrorPlan execution failed: ' + err) };
      }
      if (!planResult || !planResult.ok){
        return { ok:false, reason:'plan-failed', log: record('the bridge itself reported failure building the plan: ' + (planResult && planResult.reason)) };
      }

      const files = planResult.files || [];

      let previousFiles = null;
      try { previousFiles = await api.storageGet('lastSyncedFiles'); } catch (err){ record('could not read previously-synced file tracking (non-fatal — this run just cannot detect deletions accurately): ' + err); }
      previousFiles = previousFiles || {};

      if (!files.length && !Object.keys(previousFiles).length){
        return { ok:true, reason:'nothing-to-sync', log: record('tree is currently empty and nothing was tracked from before — nothing to write'), created:0, updated:0, unchanged:0, failed:0, trashed:0 };
      }

      let lastFingerprint = null;
      try { lastFingerprint = await api.storageGet('lastSyncedFingerprint'); } catch (err){ record('could not read last-synced fingerprint (non-fatal, just means this run cannot skip via the dirty-check): ' + err); }
      const currentFingerprint = files.map(f => f.relativePath + ':' + f.content.length).join('|');
      if (!opts.force && lastFingerprint === currentFingerprint){
        return { ok:true, reason:'unchanged', log: record('nothing has changed since the last successful sync — skipped'), created:0, updated:0, unchanged: Object.keys(previousFiles).length, failed:0, trashed:0 };
      }

      const freshPaths = new Set(files.map(f => f.relativePath));
      const stillTrackedFiles = Object.assign({}, previousFiles);

      // trash anything that was tracked before but isn't in the fresh
      // plan anymore — computed from the LAST successful sync's own
      // records, since (unlike the in-page FSA version) there is no
      // way to just list what's currently sitting on disk through
      // this API
      let trashed = 0, trashFailed = 0;
      for (const oldPath of Object.keys(previousFiles)){
        if (freshPaths.has(oldPath)) continue;
        const old = previousFiles[oldPath];
        try {
          await api.download({
            filename: subfolder + '/Trash/' + trashFileName(oldPath),
            content: old.content,
            conflictAction: 'overwrite'
          });
          if (old.downloadId != null){
            try { await api.removeFile(old.downloadId); }
            catch (err){ record('moved "' + oldPath + '" to Trash, but could not remove the original (it may already be gone): ' + err); }
          }
          trashed++;
          delete stillTrackedFiles[oldPath];
        } catch (err){
          // leave it in stillTrackedFiles — try trashing it again next
          // sync rather than losing track of it entirely
          trashFailed++;
          record('failed to move "' + oldPath + '" to Trash: ' + err);
        }
      }

      let created = 0, updated = 0, unchanged = 0, failed = 0;
      for (const file of files){
        const prev = previousFiles[file.relativePath];
        if (prev && contentsEquivalent(prev.content, file.content)){
          // genuinely unchanged — no download() call at all, not just
          // a label saying so while writing anyway
          stillTrackedFiles[file.relativePath] = prev;
          unchanged++;
          continue;
        }
        try {
          const downloadId = await api.download({
            filename: subfolder + '/' + file.relativePath,
            content: file.content,
            conflictAction: 'overwrite'
          });
          stillTrackedFiles[file.relativePath] = { content: file.content, downloadId };
          if (prev) updated++; else created++;
        } catch (err){
          // One file failing to write must not abort the rest of the
          // batch — partial progress beats total failure for a
          // multi-file mirror.
          failed++;
          record('failed to write ' + file.relativePath + ': ' + err);
        }
      }

      const allSucceeded = failed === 0 && trashFailed === 0;
      try {
        // the file-tracking map is worth persisting regardless of
        // partial failure — losing track of a file that's still
        // genuinely on disk would risk it getting wrongly trashed
        // later just because this run forgot about it
        await api.storageSet('lastSyncedFiles', stillTrackedFiles);
        if (allSucceeded) await api.storageSet('lastSyncedFingerprint', currentFingerprint);
        // if anything failed, the fingerprint is deliberately NOT
        // updated — a partial sync should not be remembered as "fully
        // synced", or a real change could get skipped by the
        // dirty-check next time
      } catch (err){
        record('could not persist sync state (non-fatal — worst case, the next sync just redoes work that already succeeded): ' + err);
      }

      return { ok: allSucceeded, reason: allSucceeded ? 'synced' : 'partial-failure', log, created, updated, unchanged, failed, trashed, trashFailed };
    } finally {
      syncInFlight = false;
    }
  }

  return { runSync, pickBrickTab, trashFileName, BRIDGE_VERSION_EXPECTED };
});
