(function(root, factory){
  if (typeof module !== 'undefined' && module.exports){
    module.exports = factory();
  } else {
    root.BrickBackupCore = factory();
  }
})(typeof self !== 'undefined' ? self : this, function(){
  'use strict';
  /* =====================================================================
     background-core.js — the actual decision logic for the companion
     extension's sync, deliberately free of any direct chrome.* calls.
     Everything the extension needs from the browser is passed in as
     `api` (queryTabs / execInPage / download / storageGet / storageSet),
     so this exact file runs unmodified both inside the real extension
     (wired to real chrome.* calls in background.js) and under a plain
     Node test with a mock `api` — no browser, no jsdom, needed to
     verify the actual worst-case handling here.
     ===================================================================== */

  const BRIDGE_VERSION_EXPECTED = 1;

  /* Multiple Brick tabs open at once — pick the most recently active
     one. Not perfect (there's no way to know which one the person
     actually considers "current"), but it's a reasonable, deterministic
     default rather than an arbitrary/undefined one. */
  function pickBrickTab(tabs){
    if (!tabs || !tabs.length) return null;
    return tabs.slice().sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  }

  let syncInFlight = false;

  async function runSync(api, opts){
    opts = opts || {};
    const log = [];
    const record = (msg) => { log.push(msg); return log; };

    if (syncInFlight) return { ok:false, reason:'already-in-progress', log: record('a sync was already running — this call was skipped rather than allowed to overlap it') };
    syncInFlight = true;

    try {
      let tabs;
      try {
        tabs = await api.queryTabs({ url: opts.matchUrls || ['*://*/*'] });
      } catch (err){
        return { ok:false, reason:'tab-query-failed', log: record('tab query failed: ' + err) };
      }

      const tab = pickBrickTab(tabs);
      if (!tab) return { ok:false, reason:'no-tab', log: record('no matching Brick tab is currently open') };

      let bridgeCheck;
      try {
        bridgeCheck = await api.execInPage(tab.id, 'checkBridge');
      } catch (err){
        return { ok:false, reason:'exec-failed', log: record('could not run a check in the page — extension may lack permission for this tab: ' + err) };
      }
      if (!bridgeCheck || !bridgeCheck.present){
        return { ok:false, reason:'bridge-missing', log: record('the page has no __brickBridge — either not loaded yet, or an old Brick version without this feature') };
      }
      if (!bridgeCheck.ready){
        return { ok:false, reason:'not-ready', log: record('bridge is present but the app has not finished booting yet') };
      }
      if (bridgeCheck.version !== BRIDGE_VERSION_EXPECTED){
        record('bridge version mismatch — extension expects ' + BRIDGE_VERSION_EXPECTED + ', page reports ' + bridgeCheck.version + ' — attempting anyway rather than refusing outright');
      }

      let planResult;
      try {
        planResult = await api.execInPage(tab.id, 'getMirrorPlan');
      } catch (err){
        return { ok:false, reason:'plan-exec-failed', log: record('getMirrorPlan execution failed: ' + err) };
      }
      if (!planResult || !planResult.ok){
        return { ok:false, reason:'plan-failed', log: record('the bridge itself reported failure building the plan: ' + (planResult && planResult.reason)) };
      }

      const files = planResult.files || [];
      if (!files.length) return { ok:true, reason:'nothing-to-sync', log: record('tree is currently empty — nothing to write'), written:0, failed:0 };

      let lastFingerprint = null;
      try { lastFingerprint = await api.storageGet('lastSyncedFingerprint'); } catch (err){ record('could not read last-synced fingerprint (non-fatal, just means this run cannot skip via the dirty-check): ' + err); }
      const currentFingerprint = files.map(f => f.relativePath + ':' + f.content.length).join('|');
      if (!opts.force && lastFingerprint === currentFingerprint){
        return { ok:true, reason:'unchanged', log: record('nothing has changed since the last successful sync — skipped'), written:0, failed:0 };
      }

      let written = 0, failed = 0;
      for (const file of files){
        try {
          await api.download({
            filename: (opts.subfolder || 'BrickBackups') + '/' + file.relativePath,
            content: file.content,
            conflictAction: 'overwrite'
          });
          written++;
        } catch (err){
          // One file failing to write must not abort the rest of the
          // batch — partial progress beats total failure for a
          // multi-file mirror.
          failed++;
          record('failed to write ' + file.relativePath + ': ' + err);
        }
      }

      if (failed === 0){
        try { await api.storageSet('lastSyncedFingerprint', currentFingerprint); }
        catch (err){ record('could not persist the fingerprint (non-fatal — worst case, the next sync just redoes work that already succeeded): ' + err); }
      }
      // if anything failed, the fingerprint is deliberately NOT updated —
      // a partial sync should not be remembered as "fully synced",
      // or a real change could get skipped by the dirty-check next time

      return { ok: failed === 0, reason: failed === 0 ? 'synced' : 'partial-failure', log, written, failed };
    } finally {
      syncInFlight = false;
    }
  }

  return { runSync, pickBrickTab, BRIDGE_VERSION_EXPECTED };
});
