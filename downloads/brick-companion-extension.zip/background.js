importScripts('background-core.js');

/* chrome.scripting.executeScript's `func` has to be a self-contained
   function literal (Chrome serializes it via toString() and re-parses
   it in the page's own context — no closures over anything outside
   it survive that trip), so the two page-side checks are written out
   in full here rather than passed in from background-core.js. The
   core logic only needs to know WHICH of the two to run, via the
   plain string key it's given. */
const PAGE_CHECKS = {
  checkBridge: () => {
    if (typeof window.__brickBridge === 'undefined') return { present:false };
    return { present:true, ready: window.__brickBridge.isReady(), version: window.__brickBridge.version };
  },
  getMirrorPlan: async () => {
    return await window.__brickBridge.getMirrorPlan();
  }
};

const chromeApi = {
  async queryTabs({ url }){
    return await chrome.tabs.query({ url });
  },
  async execInPage(tabId, whichCheck){
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: PAGE_CHECKS[whichCheck]
    });
    return results && results[0] && results[0].result;
  },
  async download({ filename, content, conflictAction }){
    // service workers can't call URL.createObjectURL for downloads in
    // all Chrome versions without an offscreen document — a data: URL
    // sidesteps that entirely and works directly from the worker
    const dataUrl = 'data:application/json;base64,' + btoa(unescape(encodeURIComponent(content)));
    return await chrome.downloads.download({ url: dataUrl, filename, conflictAction, saveAs:false });
  },
  async storageGet(key){
    const result = await chrome.storage.local.get(key);
    return result[key];
  },
  async storageSet(key, val){
    return await chrome.storage.local.set({ [key]: val });
  }
};

chrome.alarms.create('brick-sync', { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'brick-sync') BrickBackupCore.runSync(chromeApi, {});
});

// the popup's "Sync now" button talks to the background worker this way
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'sync-now'){
    BrickBackupCore.runSync(chromeApi, { force:true }).then(sendResponse);
    return true; // keeps the message channel open for the async response
  }
});
