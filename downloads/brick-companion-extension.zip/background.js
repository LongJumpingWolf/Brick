importScripts('background-core.js');

/* chrome.scripting.executeScript's `func` has to be a self-contained
   function literal (Chrome serializes it via toString() and re-parses
   it in the page's own context — no closures over anything outside
   it survive that trip), so the two page-side checks are written out
   in full here rather than passed in from background-core.js. The
   core logic only needs to know WHICH of the two to run, via the
   plain string key it's given. */
const PAGE_CHECKS = {
  checkBridge: () => {
    if (typeof window.__brickBridge === 'undefined') return { present:false };
    return { present:true, ready: window.__brickBridge.isReady(), version: window.__brickBridge.version };
  },
  getMirrorPlan: async () => {
    return await window.__brickBridge.getMirrorPlan();
  }
};

const chromeApi = {
  async queryTabs({ url }){
    return await chrome.tabs.query({ url });
  },
  async execInPage(tabId, whichCheck){
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: PAGE_CHECKS[whichCheck]
    });
    return results && results[0] && results[0].result;
  },
  async download({ filename, content, conflictAction }){
    // service workers can't call URL.createObjectURL for downloads in
    // all Chrome versions without an offscreen document — a data: URL
    // sidesteps that entirely and works directly from the worker
    const dataUrl = 'data:application/json;base64,' + btoa(unescape(encodeURIComponent(content)));
    return await chrome.downloads.download({ url: dataUrl, filename, conflictAction, saveAs:false });
  },
  async removeFile(downloadId){
    // chrome.downloads.removeFile deletes the actual file from disk
    // (not just the download-history entry) — this is what makes
    // "moved to Trash" a REAL move rather than a copy that leaves the
    // original behind. Failing here (e.g. the person already deleted
    // it by hand) is handled as non-fatal by background-core.js — the
    // content is already safely in Trash/ by the time this runs.
    return await chrome.downloads.removeFile(downloadId);
  },
  async storageGet(key){
    const result = await chrome.storage.local.get(key);
    return result[key];
  },
  async storageSet(key, val){
    return await chrome.storage.local.set({ [key]: val });
  }
};

chrome.alarms.create('brick-sync', { periodInMinutes: 5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'brick-sync') BrickBackupCore.runSync(chromeApi, {});
});

// the popup's "Sync now" button talks to the background worker this way
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'sync-now'){
    BrickBackupCore.runSync(chromeApi, { force:true }).then(sendResponse);
    return true; // keeps the message channel open for the async response
  }
  if (msg && msg.type === 'brick-tab-hidden-or-closing'){
    // close-signal.js (a persistent, lightweight content script — the
    // only one that runs on every page load, not on-demand like the
    // __brickBridge reads) sends this on visibilitychange/pagehide —
    // the earliest realistic moment to catch a tab that might be
    // about to close, including a BACKGROUND Brick tab when the whole
    // browser quits, not just the focused tab. Same runSync() as the
    // alarm, not forced — the dirty-check already makes a trigger
    // with nothing actually changed cheap, and multiple Brick tabs
    // all firing this near-simultaneously during a browser quit are
    // already safe thanks to runSync's own in-flight guard, not
    // anything special handled here. No response expected or sent —
    // this is fire-and-forget by design, since whatever's on the
    // other end (the closing tab/page) won't be listening for one.
    BrickBackupCore.runSync(chromeApi, {});
  }
});
